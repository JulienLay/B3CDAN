import React from "react";
import { View, Text } from "react-native";

export default function MessageScreen() {
  return (
    <View>
      <Text>Message Screen</Text>
    </View>
  );
}
